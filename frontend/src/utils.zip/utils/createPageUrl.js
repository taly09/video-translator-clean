export function createPageUrl(name) {
  const routes = {
    Landing: "/",
    Upload: "/upload",
    Dashboard: "/dashboard",
  };

  return routes[name] || "/";
}
