export const Transcription = {
  async list() {
    const res = await fetch("http://localhost:8765/api/transcriptions");
    if (!res.ok) throw new Error("Failed to fetch transcriptions");
    return await res.json();
  },

  async create(data) {
    const res = await fetch("http://localhost:8765/api/transcriptions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error("Failed to save transcription");
    return await res.json();
  },

  async get(id) {
    const res = await fetch(`http://localhost:8765/api/transcriptions/${id}`);
    if (!res.ok) throw new Error("Failed to fetch transcription");
    return await res.json();
  },

  async update(id, data) {
    const res = await fetch(`http://localhost:8765/api/transcriptions/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error("Failed to update transcription");
    return await res.json();
  }
};
