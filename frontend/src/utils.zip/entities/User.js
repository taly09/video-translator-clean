export const User = {
  async me() {
    const res = await fetch("http://localhost:8765/api/user/me", {
      credentials: "include", // חשוב לשמירת session
    });

    if (!res.ok) throw new Error("Not logged in");
    return await res.json();
  },

  async login() {
    window.location.href = "http://localhost:8765/login/google";
  },

 async logout() {
  try {
    await fetch("http://localhost:8765/logout", {
      method: "GET",
      credentials: "include", // חשוב כדי ש־Flask ידע את ה־session
    });

    window.location.href = "/"; // אחרי ההתנתקות תחזור לדף הבית
  } catch (err) {
    console.error("Logout failed:", err);
     }
    }

};
