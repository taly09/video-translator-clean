import { useState, useEffect, useRef } from "react";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export function useTranscriptionBackend() {
  const [status, setStatus] = useState({
    step: "idle",
    stepLabel: "",
    progress: 0,
  });
  const [isPolling, setIsPolling] = useState(false);
  const [error, setError] = useState(null);
  const pollIntervalRef = useRef(null);

  const resetState = () => {
    setStatus({ step: "idle", stepLabel: "", progress: 0 });
    setIsPolling(false);
    setError(null);
    clearInterval(pollIntervalRef.current);
  };

  const pollStatus = async (taskId) => {
    try {
      const res = await fetch(`${API_BASE_URL}/api/transcribe/status/${taskId}`);
      if (!res.ok) throw new Error("Failed to get status");
      const data = await res.json();

      setStatus({
        step: data.status,
        stepLabel: data.step || "מעבד...",
        progress: data.progress || 0,
      });

      if (data.status === "completed" || data.progress >= 100) {
        clearInterval(pollIntervalRef.current);
        setIsPolling(false);
      }

      if (data.status === "failed") {
        clearInterval(pollIntervalRef.current);
        setError(data.message || "תהליך נכשל");
        setStatus({ step: "failed", stepLabel: "נכשל", progress: 0 });
      }

    } catch (err) {
      setError("בעיה בחיבור לשרת: " + err.message);
    }
  };

  const uploadAndProcess = async (file, { language, translate_to }) => {
    const formData = new FormData();
    formData.append("video", file);
    formData.append("language", language);
    formData.append("translate_to", translate_to || "");

    try {
      const res = await fetch(`${API_BASE_URL}/api/transcribe/upload`, {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || "Upload failed");
      }

      const data = await res.json();

      if (data.task_id) {
        setIsPolling(true);
        setStatus({ step: "processing", stepLabel: "מעבד...", progress: 0 });

        pollIntervalRef.current = setInterval(() => {
          pollStatus(data.task_id);
        }, 3000);

        return data.task_id; // ✅ מחזיר את ה-ID כמו שצריך
      } else {
        throw new Error("No task_id returned from server");
      }

    } catch (err) {
      setError("שגיאה: " + err.message);
      setIsPolling(false);
      return null;
    }
  };

  useEffect(() => {
    return () => clearInterval(pollIntervalRef.current);
  }, []);

  return {
    status,
    isPolling,
    error,
    uploadAndProcess,
    resetState,
  };
}
