import React from "react";
import { FcGoogle } from "react-icons/fc";

export default function GoogleLoginButton() {
  return (
    <a
      href="http://localhost:8765/login/google"
      className="flex items-center justify-center gap-3 bg-white border border-gray-300 rounded-lg px-4 py-2 shadow-sm hover:shadow-md transition"
    >
      <FcGoogle className="w-5 h-5" />
      <span className="text-sm font-medium text-gray-700">התחבר עם Google</span>
    </a>
  );
}
