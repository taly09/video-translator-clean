import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils/createPageUrl";
import { Transcription } from "@/entities/Transcription";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowRight, Clock, Calendar, Pencil, Save, Copy,
  Download, FileText, Play, Pause, Volume2, ChevronLeft,
  ChevronRight, AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { srtToText } from "@/components/transcription/TranscriptionConverter";

// URL Constants
const API_BASE_URL = "http://localhost:8765";

export default function TranscriptionView() {
  const [transcription, setTranscription] = useState(null);
  const [srtContent, setSrtContent] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioRef, setAudioRef] = useState(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    loadTranscription();
  }, []);

  const loadTranscription = async () => {
    setIsLoading(true);
    try {
      // 1. Try to get transcription ID from URL
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get('id');

      // 2. Load transcription record from our system
      if (id) {
        const data = await Transcription.get(id);
        if (!data) {
          throw new Error("התמלול לא נמצא");
        }
        setTranscription(data);
      } else {
        // If no ID, try to fetch from Flask latest result
        await loadFromFlaskResults();
        return;
      }

      try {
        // 3. Try to fetch the actual content from Flask backend
        const response = await fetch(`${API_BASE_URL}/results`, {
          credentials: 'include' // Include cookies for session management
        });

        if (!response.ok) {
          console.warn("Could not fetch results from Flask backend");
          // Fallback to local content if available
        } else {
          const html = await response.text();
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, 'text/html');

          // Extract subtitle content
          const preElement = doc.querySelector('pre');
          if (preElement && preElement.textContent) {
            setSrtContent(preElement.textContent);

            // Convert SRT to plain text
            const plainText = srtToText(preElement.textContent);

            // Update the transcription with content from Flask backend
            await Transcription.update(id, {
              content: plainText,
              status: "done"
            });

            setTranscription(prev => ({
              ...prev,
              content: plainText,
              status: "done"
            }));

            setEditedContent(plainText);
          }
        }
      } catch (flaskError) {
        console.error("Error fetching from Flask backend:", flaskError);
        // Continue with local data
      }

    } catch (error) {
      console.error("Error loading transcription:", error);
      setError(error.message || "אירעה שגיאה בטעינת התמלול");
    } finally {
      setIsLoading(false);
    }
  };

  const loadFromFlaskResults = async () => {
    try {
      // Fetch results directly from Flask
      const response = await fetch(`${API_BASE_URL}/results`, {
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error("לא נמצאו תוצאות תמלול במערכת");
      }

      const html = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');

      // Extract data from the HTML
      const preElement = doc.querySelector('pre');
      if (!preElement) {
        throw new Error("תמלול לא זמין");
      }

      const srtText = preElement.textContent;
      const plainText = srtToText(srtText);
      setSrtContent(srtText);

      // Create new transcription record
      const newTranscription = await Transcription.create({
        title: "תמלול חדש" + " " + new Date().toLocaleString(),
        content: plainText,
        status: "done",
        language: "he", // Default language
      });

      setTranscription(newTranscription);
      setEditedContent(plainText);

      // Update URL to include the new ID
      window.history.replaceState(
        null,
        "",
        createPageUrl(`TranscriptionView?id=${newTranscription.id}`)
      );
    } catch (error) {
      console.error("Error loading from Flask results:", error);
      setError(error.message);
    }
  };

  const handleBack = () => {
    navigate(createPageUrl("Transcriptions"));
  };

  const toggleEdit = () => {
    if (isEditing) {
      setEditedContent(transcription.content || "");
    }
    setIsEditing(!isEditing);
  };

  const saveChanges = async () => {
    setIsSaving(true);
    try {
      await Transcription.update(transcription.id, {
        content: editedContent,
        status: "done" // Update status if it was processing
      });

      setTranscription({
        ...transcription,
        content: editedContent,
        status: "done"
      });

      setIsEditing(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (error) {
      console.error("Error saving changes:", error);
      setError("אירעה שגיאה בשמירת השינויים");
    } finally {
      setIsSaving(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(transcription.content || "");
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const downloadText = () => {
    const element = document.createElement("a");
    const file = new Blob([transcription.content || ""], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${transcription.title}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const downloadSrt = () => {
    if (!srtContent) return;

    const element = document.createElement("a");
    const file = new Blob([srtContent], {type: 'text/srt'});
    element.href = URL.createObjectURL(file);
    element.download = `${transcription.title}.srt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const togglePlay = () => {
    if (!audioRef) return;

    if (isPlaying) {
      audioRef.pause();
    } else {
      audioRef.play();
    }
    setIsPlaying(!isPlaying);
  };

  const formatDuration = (seconds) => {
    if (!seconds) return "00:00";
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // בחיים אמיתיים, היינו עדכנים את הזמן הנוכחי כשהאודיו מתנגן
  useEffect(() => {
    if (audioRef && isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= (transcription?.duration || 0)) {
            clearInterval(interval);
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [audioRef, isPlaying, transcription]);

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>

          <Button onClick={handleBack}>
            <ArrowRight className="h-4 w-4 ml-2" />
            חזרה לרשימת התמלולים
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Success notification */}
        {showSuccess && (
          <Alert className="mb-6 bg-green-50 text-green-800 border-green-200">
            <AlertDescription>הפעולה בוצעה בהצלחה</AlertDescription>
          </Alert>
        )}

        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            className="mb-2"
            onClick={handleBack}
          >
            <ArrowRight className="h-4 w-4 ml-2" />
            חזרה לרשימת התמלולים
          </Button>

          {isLoading ? (
            <Skeleton className="h-8 w-2/3 mb-2" />
          ) : (
            <h1 className="text-3xl font-bold mb-2">{transcription.title}</h1>
          )}

          {isLoading ? (
            <div className="flex gap-3">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-5 w-20" />
            </div>
          ) : (
            <div className="flex flex-wrap gap-3">
              <Badge className={
                transcription.status === "processing" ? "bg-amber-100 text-amber-800 border-amber-200" :
                transcription.status === "done" ? "bg-green-100 text-green-800 border-green-200" :
                "bg-red-100 text-red-800 border-red-200"
              }>
                {transcription.status === "processing" ? "בתהליך" :
                 transcription.status === "done" ? "הושלם" : "שגיאה"}
              </Badge>

              <Badge variant="outline">
                {transcription.language === "he" ? "עברית" :
                 transcription.language === "en" ? "אנגלית" :
                 transcription.language === "ar" ? "ערבית" :
                 transcription.language === "ru" ? "רוסית" :
                 transcription.language === "fr" ? "צרפתית" :
                 transcription.language === "es" ? "ספרדית" : transcription.language}
              </Badge>

              <div className="flex items-center text-sm text-gray-500">
                <Clock className="h-3 w-3 ml-1" />
                {formatDuration(transcription.duration)}
              </div>

              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="h-3 w-3 ml-1" />
                {format(new Date(transcription.created_date), "dd/MM/yyyy")}
              </div>
            </div>
          )}
        </div>

        {/* Audio player - will be available in a real implementation */}
        {!isLoading && transcription.file_url && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-full bg-blue-100 text-blue-700 hover:bg-blue-200 hover:text-blue-800"
                  onClick={togglePlay}
                >
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 mr-[-2px]" />}
                </Button>

                <div className="flex-grow">
                  <div className="relative h-1 bg-gray-200 rounded-full">
                    <div
                      className="absolute top-0 left-0 h-full bg-blue-600 rounded-full"
                      style={{width: `${(currentTime / (transcription.duration || 1)) * 100}%`}}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>{formatDuration(currentTime)}</span>
                    <span>{formatDuration(transcription.duration)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-gray-700">
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-gray-700">
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-gray-700">
                    <Volume2 className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Hidden audio element */}
              <audio
                ref={ref => setAudioRef(ref)}
                src={transcription.file_url}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
                style={{display: 'none'}}
              />
            </CardContent>
          </Card>
        )}

        {/* Content and actions */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">תוכן התמלול</h2>

            <div className="flex gap-2">
              {!isLoading && transcription.status === "done" && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyToClipboard}
                  >
                    <Copy className="h-4 w-4 ml-2" />
                    העתק
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadText}
                  >
                    <Download className="h-4 w-4 ml-2" />
                    הורד טקסט
                  </Button>

                  {srtContent && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={downloadSrt}
                    >
                      <Download className="h-4 w-4 ml-2" />
                      הורד SRT
                    </Button>
                  )}
                </>
              )}

              {!isLoading && (
                <Button
                  variant={isEditing ? "outline" : "default"}
                  size="sm"
                  onClick={toggleEdit}
                  disabled={transcription.status === "processing"}
                >
                  {isEditing ? "ביטול" : (
                    <>
                      <Pencil className="h-4 w-4 ml-2" />
                      ערוך
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
            </div>
          ) : transcription.status === "processing" ? (
            <Card className="p-12 bg-gray-50 border-dashed text-center">
              <div className="flex flex-col items-center justify-center">
                <FileText className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-xl font-medium text-gray-700 mb-2">התמלול מעובד</h3>
                <p className="text-gray-500 mb-4">אנו מעבדים את הקובץ שלך, פעולה זו יכולה להימשך מספר דקות</p>
                <div className="flex items-center justify-center">
                  <div className="animate-spin h-4 w-4 border-2 border-blue-600 border-r-transparent rounded-full ml-2"></div>
                  מעבד...
                </div>
              </div>
            </Card>
          ) : isEditing ? (
            <div className="space-y-4">
              <Textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                rows={20}
                className="font-light leading-relaxed"
              />

              <div className="flex justify-end">
                <Button
                  onClick={saveChanges}
                  disabled={isSaving}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isSaving ? (
                    <div className="flex items-center">
                      <div className="animate-spin h-4 w-4 border-2 border-white border-r-transparent rounded-full ml-2"></div>
                      שומר...
                    </div>
                  ) : (
                    <>
                      <Save className="h-4 w-4 ml-2" />
                      שמור שינויים
                    </>
                  )}
                </Button>
              </div>
            </div>
          ) : transcription.content ? (
            <div className="bg-white border rounded-lg p-6 shadow-sm">
              <div
                className="whitespace-pre-wrap font-light leading-relaxed"
                style={{direction: transcription.language === "he" || transcription.language === "ar" ? "rtl" : "ltr"}}
              >
                {transcription.content}
              </div>
            </div>
          ) : (
            <Card className="p-12 bg-gray-50 border-dashed text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">אין תוכן זמין</h3>
              <p className="text-gray-500">לא נמצא תוכן לתמלול זה</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}