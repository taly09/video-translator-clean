
import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils/createPageUrl";
import GoogleLoginButton from "@/components/GoogleLoginButton";

import { 
  FileText, 
  Mic, 
  Zap, 
  Globe, 
  Clock, 
  ChevronRight,
  PlayCircle,
  Upload
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="lg:w-1/2 text-center lg:text-right"
            >
              <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
                תמלול וידאו חכם בעברית
              </h1>
              <p className="text-xl text-blue-100 mb-8">
                פתרון מתקדם לתמלול אוטומטי של וידאו וקבצי אודיו. מהיר, מדויק וקל לשימוש.
              </p>
              <div className="flex flex-wrap justify-center lg:justify-start gap-4">
                <Link to={createPageUrl("Upload")}>
                  <Button
  size="lg"
  className="bg-white text-blue-700 font-semibold hover:bg-blue-100 border border-blue-200 shadow-md transition duration-200"
>
  התחל עכשיו
  <ChevronRight className="w-5 h-5 mr-1" />
</Button>

                </Link>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  <PlayCircle className="w-5 h-5 ml-2" />
                  צפה בהדגמה
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="lg:w-1/2"
            >
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-white/20">
                <img
                  src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Video transcription"
                  className="rounded-lg w-full object-cover h-[300px]"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Login With Google Section */}
<section className="bg-white py-16">
  <div className="container mx-auto px-4 text-center">
    <h2 className="text-2xl font-bold text-gray-800 mb-4">
      התחבר עם Google לשמירה אוטומטית של התמלולים שלך
    </h2>
    <p className="text-gray-600 mb-6">
      התחברות תאפשר לך לגשת לתמלולים קודמים ולשמור את ההיסטוריה שלך.
    </p>
    <div className="flex justify-center">
      <GoogleLoginButton />
    </div>
  </div>
</section>


      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">יתרונות המערכת</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              המערכת שלנו מציעה פתרון מקיף לתמלול וידאו עם טכנולוגיה מתקדמת
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Mic className="w-6 h-6 text-blue-600" />}
              title="תמלול מדויק"
              description="תמלול מדויק באמצעות מודל Whisper המתקדם, המזהה ביטויים ומונחים בשפה העברית"
            />

            <FeatureCard
              icon={<Globe className="w-6 h-6 text-blue-600" />}
              title="תמיכה במגוון שפות"
              description="תמיכה בעברית, אנגלית, ערבית ועוד שפות רבות, כולל זיהוי אוטומטי של השפה"
            />

            <FeatureCard
              icon={<Zap className="w-6 h-6 text-blue-600" />}
              title="מהירות עיבוד"
              description="עיבוד מהיר במיוחד - תמלול וידאו באורך של שעה מוכן תוך דקות ספורות"
            />

            <FeatureCard
              icon={<FileText className="w-6 h-6 text-blue-600" />}
              title="פורמטים מרובים"
              description="ייצוא התמלול בפורמטים שונים: SRT, טקסט, וגם וידאו עם כתוביות מובנות"
            />

            <FeatureCard
              icon={<Clock className="w-6 h-6 text-blue-600" />}
              title="חיסכון בזמן"
              description="חסוך שעות של עבודה ידנית עם תמלול אוטומטי המסתיים תוך דקות"
            />

            <FeatureCard
              icon={<Globe className="w-6 h-6 text-blue-600" />}
              title="תרגום אוטומטי"
              description="תרגום אוטומטי של הכתוביות לשפות שונות בלחיצת כפתור"
            />
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">מוכנים להתחיל?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            העלו קובץ וידאו עכשיו וקבלו תמלול איכותי תוך דקות. ללא צורך בידע טכני.
          </p>
          <Link to={createPageUrl("Upload")}>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              העלאת וידאו לתמלול
              <Upload className="w-5 h-5 mr-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <FileText className="w-6 h-6 text-blue-400 ml-2" />
              <span className="text-xl font-bold">תמלול חכם</span>
            </div>
            <div className="text-gray-400 text-sm">
              © {new Date().getFullYear()} כל הזכויות שמורות
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all"
    >
      <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
}
