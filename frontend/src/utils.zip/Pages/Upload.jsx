import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils/createPageUrl";
import { Transcription } from "@/entities/Transcription";
import { useTranscriptionBackend } from "@/components/transcription/FlaskBackendConnector";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

import {
  Upload as UploadIcon, Mic, File as FileIcon,
  Headphones, XCircle, Loader2, CheckCircle, AlertCircle
} from "lucide-react";

export default function UploadPage() {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [language, setLanguage] = useState("auto");
  const [translateTo, setTranslateTo] = useState("");
  const [showLimitAlert, setShowLimitAlert] = useState(false);
  const [transcriptionId, setTranscriptionId] = useState(null);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  const {
    status,
    error: backendError,
    isPolling,
    uploadAndProcess,
    resetState
  } = useTranscriptionBackend();

  useEffect(() => {
  console.log("👀 EFFECT TRIGGERED");
  console.log("status.step =", status.step);
  console.log("transcriptionId =", transcriptionId);

  if (
    ["done", "completed", "success"].includes(status.step) &&
    transcriptionId
  ) {
    console.log("✅ navigating to result page");
    setTimeout(() => {
      navigate(createPageUrl(`TranscriptionView?id=${transcriptionId}`));
    }, 1500);
  }
}, [status.step, transcriptionId]);


  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      if (!title) {
        const name = selected.name.split(".").slice(0, -1).join(" ").replace(/[-_]/g, " ");
        setTitle(name);
      }
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;

    const isLoggedIn = await fetch("http://localhost:8765/api/user/me", {
      credentials: "include"
    }).then(res => res.ok).catch(() => false);

    if (!isLoggedIn) {
      const allowed = window.checkGuestLimit?.();
      if (!allowed) {
        setShowLimitAlert(true);
        return;
      }
    }

    try {
      const newTranscription = await Transcription.create({
  title: title || file.name,
  file_url: URL.createObjectURL(file),
  language,
  status: "processing",
  content: ""
});

console.log("🔥 newTranscription =", newTranscription);
console.log("📛 newTranscription.id =", newTranscription?.id);

const taskId = await uploadAndProcess(file, {
  language,
  translate_to: translateTo
});

console.log("🎯 taskId from backend:", taskId);
setTranscriptionId(taskId);

      if (!isLoggedIn) {
        window.incrementGuestCounter?.();
      }

    } catch (err) {
      console.error("Upload error:", err);
      resetState();
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">תמלול חדש</h1>

        {showLimitAlert && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex justify-between items-center flex-wrap gap-2">
              <span>עשית כבר תמלול אחד. כדי להמשיך, התחבר לחשבון שלך 👇</span>
              <Button onClick={() => navigate("/login")}>התחבר</Button>
            </AlertDescription>
          </Alert>
        )}

        {backendError && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{backendError}</AlertDescription>
          </Alert>
        )}

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mic className="h-5 w-5" />
              העלאת קובץ לתמלול
            </CardTitle>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleUpload}>
              {!file ? (
                <div
                  className="border-2 border-dashed rounded-lg p-8 mb-6 text-center cursor-pointer hover:bg-gray-50"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="video/*,audio/*"
                    className="hidden"
                  />
                  <div className="bg-blue-100 text-blue-700 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <UploadIcon className="h-8 w-8" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">גרור לכאן קובץ</h3>
                  <p className="text-gray-500 mb-4">או לחץ לבחירת קובץ</p>
                  <div className="flex justify-center gap-2 text-sm text-gray-500">
                    <Badge variant="secondary">MP4</Badge>
                    <Badge variant="secondary">MP3</Badge>
                    <Badge variant="secondary">WAV</Badge>
                  </div>
                </div>
              ) : (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="bg-blue-100 text-blue-700 p-2 rounded-lg ml-3">
                        <Headphones className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="font-medium">{file.name}</p>
                        <p className="text-sm text-gray-500">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setFile(null);
                        resetState();
                      }}
                    >
                      <XCircle className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="title">כותרת</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="הזן כותרת לתמלול"
                    disabled={isPolling}
                  />
                </div>

                <div>
                  <Label htmlFor="language">שפת המקור</Label>
                  <Select
                    value={language}
                    onValueChange={setLanguage}
                    disabled={isPolling}
                  >
                    <SelectTrigger><SelectValue placeholder="בחר שפה" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">זיהוי אוטומטי</SelectItem>
                      <SelectItem value="he">עברית</SelectItem>
                      <SelectItem value="en">אנגלית</SelectItem>
                      <SelectItem value="ar">ערבית</SelectItem>
                      <SelectItem value="ru">רוסית</SelectItem>
                      <SelectItem value="fr">צרפתית</SelectItem>
                      <SelectItem value="es">ספרדית</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="translateTo">תרגם לשפה</Label>
                  <Select
                    value={translateTo}
                    onValueChange={setTranslateTo}
                    disabled={isPolling}
                  >
                    <SelectTrigger><SelectValue placeholder="בחר שפה לתרגום" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">ללא תרגום</SelectItem>
                      <SelectItem value="he">עברית</SelectItem>
                      <SelectItem value="en">אנגלית</SelectItem>
                      <SelectItem value="ar">ערבית</SelectItem>
                      <SelectItem value="ru">רוסית</SelectItem>
                      <SelectItem value="fr">צרפתית</SelectItem>
                      <SelectItem value="es">ספרדית</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {isPolling && (
                <div className="mb-6">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="flex items-center">
                      {status.step === "done" ? (
                        <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                      ) : (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      )}
                      {status.stepLabel || "מעבד..."}
                    </span>
                    <span>{Math.round(status.progress || 0)}%</span>
                  </div>
                  <Progress value={status.progress || 0} className="h-2" />
                </div>
              )}

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={isPolling || !file}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isPolling ? "מעבד..." : "התחל תמלול"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="bg-blue-50 border border-blue-100 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-3 text-blue-800">טיפים לתמלול מוצלח:</h3>
          <ul className="space-y-2 text-blue-700">
            <li className="flex items-start"><FileIcon className="h-4 w-4 ml-2" /> העלה קובץ באיכות טובה ללא רעשי רקע</li>
            <li className="flex items-start"><FileIcon className="h-4 w-4 ml-2" /> בחר שפה ידנית אם ידועה מראש</li>
            <li className="flex items-start"><FileIcon className="h-4 w-4 ml-2" /> קבצים קצרים (עד 60 דקות) מעובדים מהר</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
