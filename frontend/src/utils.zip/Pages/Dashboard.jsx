import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils/createPageUrl";
import { FileText, Upload, Search, Filter, ChevronRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Transcription } from "@/entities/Transcription";
import { User } from "@/entities/User";
import PageHeader from "../components/ui/PageHeader";
import TranscriptionCard from "../components/dashboard/TranscriptionCard";
import TranscriptionDetails from "../components/dashboard/TranscriptionDetails";

export default function Dashboard() {
  const [transcriptions, setTranscriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedTranscription, setSelectedTranscription] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);

      try {
        const userData = await User.me();
        setUser(userData);

        const data = await Transcription.list();
        setTranscriptions(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, []);

  const filteredTranscriptions = transcriptions.filter(t => {
    const matchesSearch = t.original_filename?.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleCardClick = (transcription) => {
    setSelectedTranscription(transcription);
  };

  const closeDetails = () => {
    setSelectedTranscription(null);
  };

  return (
    <div>
      <PageHeader
        title="התמלולים שלי"
        subtitle="צפה בכל התמלולים שלך וגש לכל המידע"
        icon={<FileText className="w-7 h-7" />}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className={`md:col-span-${selectedTranscription ? 2 : 3}`}>
          <div className="mb-4 flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="חפש לפי שם קובץ..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>

            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[160px]">
                  <Filter className="w-4 h-4 ml-2 text-gray-500" />
                  <SelectValue placeholder="סנן לפי סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">כל הסטטוסים</SelectItem>
                  <SelectItem value="completed">הושלם</SelectItem>
                  <SelectItem value="processing">בתהליך</SelectItem>
                  <SelectItem value="failed">נכשל</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="all" className="mb-6">
            <TabsList>
              <TabsTrigger value="all">הכל</TabsTrigger>
              <TabsTrigger value="recent">אחרונים</TabsTrigger>
              <TabsTrigger value="favorite">מועדפים</TabsTrigger>
            </TabsList>
          </Tabs>

          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-10 h-10 text-blue-500 animate-spin mb-4" />
              <p className="text-gray-500">טוען תמלולים...</p>
            </div>
          ) : filteredTranscriptions.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTranscriptions.map((transcription) => (
                <TranscriptionCard
                  key={transcription.id}
                  transcription={transcription}
                  onClick={() => handleCardClick(transcription)}
                />
              ))}
            </div>
          ) : transcriptions.length > 0 ? (
            <div className="bg-gray-50 border rounded-lg p-8 text-center">
              <p className="text-gray-500 mb-2">אין תוצאות התואמות לחיפוש שלך</p>
              <Button variant="ghost" onClick={() => {
                setSearch("");
                setStatusFilter("all");
              }}>
                נקה מסננים
              </Button>
            </div>
          ) : (
            <div className="bg-gray-50 border rounded-lg p-8 text-center">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">עוד אין לך תמלולים</h3>
              <p className="text-gray-500 mb-4">התחל עכשיו עם העלאת הוידאו הראשון שלך</p>
              <Link to={createPageUrl("Upload")}>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Upload className="w-4 h-4 ml-2" />
                  העלה וידאו
                </Button>
              </Link>
            </div>
          )}

          {filteredTranscriptions.length > 0 && (
            <div className="mt-6 text-center">
              <Link to={createPageUrl("Upload")}>
                <Button variant="outline" className="gap-2">
                  העלה וידאו נוסף
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          )}
        </div>

        {selectedTranscription && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="md:col-span-1"
          >
            <TranscriptionDetails
              transcription={selectedTranscription}
              onClose={closeDetails}
            />
          </motion.div>
        )}
      </div>
    </div>
  );
}