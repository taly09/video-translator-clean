import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils/createPageUrl";
import { User } from "../entities/User";
import {
  FileText,
  Upload,
  Home,
  Menu,
  X,
  LogOut,
  Settings,
  User as UserIcon
} from "lucide-react";
import { Button } from "../components/ui/button";

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    async function fetchUser() {
      try {
        const userData = await User.me();
        setUser(userData);
      } catch (error) {
        console.log("User not authenticated");
      } finally {
        setLoading(false);
      }
    }
    fetchUser();
  }, []);

  const isActive = (pageName) => {
    return location.pathname === createPageUrl(pageName);
  };

  const handleLogout = async () => {
    await User.logout();
    window.location.href = createPageUrl("Landing");
  };

  const handleLogin = async () => {
    await User.login();
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden" dir="rtl">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 right-0 z-50 h-full w-64 bg-white border-l border-gray-200 shadow-lg transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h1 className="text-xl font-bold text-blue-600 flex items-center gap-2">
            <FileText className="w-6 h-6" />
            <span>תמלול חכם</span>
          </h1>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-4">
          <nav className="space-y-1">
            <Link
              to={createPageUrl("Landing")}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                isActive("Landing")
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => setSidebarOpen(false)}
            >
              <Home className="w-5 h-5" />
              <span>דף הבית</span>
            </Link>

            <Link
              to={createPageUrl("Upload")}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                isActive("Upload")
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => setSidebarOpen(false)}
            >
              <Upload className="w-5 h-5" />
              <span>העלאת וידאו</span>
            </Link>

            <Link
              to={createPageUrl("Dashboard")}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                isActive("Dashboard")
                  ? "bg-blue-50 text-blue-600"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
              onClick={() => setSidebarOpen(false)}
            >
              <FileText className="w-5 h-5" />
              <span>התמלולים שלי</span>
            </Link>
          </nav>
        </div>

        <div className="absolute bottom-0 right-0 left-0 p-4 border-t">
          {loading ? (
            <div className="h-10 bg-gray-200 animate-pulse rounded-lg"></div>
          ) : user ? (
            <div className="space-y-2">
              <div className="flex items-center gap-3 p-2">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="overflow-hidden">
                  <p className="font-medium text-gray-900 truncate">
                    {user.full_name}
                  </p>
                  <p className="text-sm text-gray-500 truncate">
                    {user.email}
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 ml-2" />
                התנתק
              </Button>
            </div>
          ) : (
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={handleLogin}
            >
              <UserIcon className="w-4 h-4 ml-2" />
              התחבר עכשיו
            </Button>
          )}
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top navbar */}
        <header className="bg-white border-b border-gray-200 shadow-sm">
          <div className="flex items-center justify-between p-4">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>

            <div className="flex items-center">
              {user && (
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                  >
                    <LogOut className="w-4 h-4 ml-1" />
                    התנתק
                  </Button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto">
          <div className="container p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}