import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import UploadPage from "./Pages/Upload";
import Landing from "./Pages/Landing";
import Dashboard from "./Pages/Dashboard";
import Layout from "./Pages/Layout";
import SettingsPage from "./Pages/SettingsPage";
import TranscriptionView from "@/pages/TranscriptionView";
import LoginPage from "./Pages/Login"; // או הנתיב הנכון בהתאם למיקום הקובץ




export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/upload" element={<UploadPage />} />
          <Route path="/TranscriptionView" element={<TranscriptionView />} />
          <Route path="/" element={<UploadPage />} />

          <Route path="/login" element={<LoginPage />} /> {/* ⬅️ חשוב */}



        </Routes>
      </Layout>
    </BrowserRouter>
  );
}